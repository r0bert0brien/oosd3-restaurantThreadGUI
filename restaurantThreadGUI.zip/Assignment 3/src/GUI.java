import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;


//Author: Robert O'Brien
//Student Number: C20436696
//Publish Date: 02/04/2022

public class GUI extends JFrame{

	static ArrayList<Item> items = new ArrayList<Item>();
	static ArrayList<String> messages = new ArrayList<String>();
	boolean done = false;//Variable used to Signal to the User their food is Done
	Chef c = new Chef(this, items);
	Waiter w = new Waiter(c, items);
	public GUI() {
		super("Robert's Restaurant");
		
		JPanel panel = new JPanel(new BorderLayout());//Blank Pannel
		panel.setVisible(true);
		this.add(panel);

		JPanel tArea = new JPanel();//Text Pannel which is Added onto Main Pannel
		tArea.setVisible(true);
		panel.add(tArea, BorderLayout.NORTH);

		JPanel rest = new JPanel();//Space for Buttons on Pannel which is Added onto Main Pannel
		rest.setVisible(true);
		panel.add(rest, BorderLayout.SOUTH);

		//Text Area
		JTextArea textArea = new JTextArea(20,60);//Text Box added onto the Text Pannel
		textArea.setEditable(false);
		textArea.setVisible(true);
		tArea.add(textArea);

		//Placing an Order Button
		JButton placeOrder = new JButton("Place an Order");
		placeOrder.setVisible(true);
		rest.add(placeOrder);

		//Taking the Order In
		placeOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JLabel courseLbl = new JLabel("Course:");
				JTextField courseField = new JTextField();
				JLabel foodLbl = new JLabel("Item:");
				JTextField foodField = new JTextField();
				String message = "Please enter your Order: ";
				int result = JOptionPane.showOptionDialog(panel, 
						new Object[] { message, courseLbl, courseField, foodLbl, foodField}
				,  "Place an Order", JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE, null, null, null);
				if (result == JOptionPane.YES_OPTION)
				{
					String course = courseField.getText();
					String food = foodField.getText();
					Item i1 = new Item(course,food);
					items.add(i1);
					//**PROBLEM AREA, Seems to be ignoring the code below and starting up the Waiter Thread regardless if its alive or not
					while(!w.isAlive()) {
						w.start();
					}
					textArea.append(items.toString()+"\n");//Updating the Text Box with Each Order Placed
						
					
				}
			}});
		

		
			
		
	}

	public static void main(String[] args) {
		GUI act = new GUI();
		act.setSize(700,500);
		act.setVisible(true);
		act.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
	void displayDone() {//Method to notify the user that their food is done
		JOptionPane.showMessageDialog(null, "Order is Done!");
	}
}

class Waiter extends Thread{

	Item i;
	Chef c = null;
	private ArrayList<Item> items;
	public Waiter(Chef c, ArrayList<Item> items) {
		this.c = c;
		this.items = items;
	}

	public void run() {


		System.out.println("Thread WAITER is Running...");

		while(!items.isEmpty()) {
			i = items.get(0);
			synchronized(c){
				//Pass to Chef
				c.i = i;
				//Start Chef
				while(!c.isAlive()) {
					c.start();
				}
				c.notify();//Notify Chef

				try {
					c.wait();
					items.remove(0);
				} catch (InterruptedException e) {}
				//**remove order from list
			}//end synchronized
		}//end run
	}
}

class Chef extends Thread{
	Item i;
	GUI g = null;
	private ArrayList<Item> items;

	public Chef( GUI g, ArrayList<Item> items) {
		this.g = g;
		this.items = items;
	}
	public void run() {
		synchronized(this){
			System.out.println("Thread is Running...");


			while(!items.isEmpty()) {
				System.out.println("Preparing order....");
				try {
					this.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(i.toString());
				g.displayDone();//Calling the Notify User Method
				this.notify();
				try {
					this.wait();
				} catch (InterruptedException e) {}
				//Return to Waiter

			}//end synchronized
		}
	}//end run
}
