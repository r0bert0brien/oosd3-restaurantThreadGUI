
public class Item {

	String course;
	String foodName;

	public Item(String course, String foodName) {
		this.course = course;
		this.foodName = foodName;
	}

	public String getCourse() {
		return this.course;
	}

	public String getFoodName() {
		return this.foodName;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	
	public String toString() {
		return "Course: " + this.course + "\nFood Name: " + this.foodName;
	}
}
